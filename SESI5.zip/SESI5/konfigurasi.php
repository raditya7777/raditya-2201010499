<?php 
    //konfigurasi dbms mysql
    define("DBHOST", "127.0.0.1");
    define("DBUSER", "root");
    define("DBPASS", "");
    define("DBNAME", "db_mahasiswa");
    define("DBPORT", "3306");
