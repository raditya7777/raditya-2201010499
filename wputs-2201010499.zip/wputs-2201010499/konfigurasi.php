<?php
    //konfigurasi koneksi ke DBMS mysql
    define("DBHOST", "localhost");
    define("DBUSER", "root");
    define("DBPASS", "");
    define("DBPORT","3306");
    define("DBNAME", "progmhs");